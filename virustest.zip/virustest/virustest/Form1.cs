﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Security.Cryptography;


using System.IO;namespace virustest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //show s the browser dialog
            folderBrowserDialog1.ShowDialog();
            //shows selected folder in textbox1
            textBox1.Text = (folderBrowserDialog1.SelectedPath);
            textBox1.Refresh();
        }

        private void folderBrowserDialog1_HelpRequest(object sender, EventArgs e)
        {
           
        }


        private void mdsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Console.WriteLine("1");
            //for each line from browser dialog print each file
            foreach (string f in System.IO.Directory.GetFiles(folderBrowserDialog1.SelectedPath))
            {
                Console.WriteLine("1");
                //creates the md5's for the files 
                MD5 md5 = MD5.Create();
                var stream = File.OpenRead(f);
                string md5check = BitConverter.ToString(md5.ComputeHash(stream)).Replace("-", "").ToLower();
                //add the items file and md5 into listbox1
                listBox1.Items.Add(f + " MD5:  " + md5check);


                //if the md5 match this
                {
                    if (md5check == "f3a555710c7cbe1bdc1e743f409b8e0e")
                    {//then show this message plus the file location
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }


                    else if (md5check == "ddf7c81e452c6da8981ed685f8ade5c0")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }


                    else if (md5check == "2fd5588ef6d03d238a490c348dc388ea")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }


                    else if (md5check == "4bb211393828d585cb5396a273008d94")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }



                    else if (md5check == "74a8c01b69adedd7f1330245cd994821")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }


                    else if (md5check == "158c16d067a3e27c1234b03aa69120b2")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }


                    else if (md5check == "8c7259ff20cf6ebe02edf455ac2db271")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }


                    else if (md5check == "a630b73bc030fc2146edcf66586d316a")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }


                    else if (md5check == "d57dfbcb4d658c0c03f1de76eedc57f2")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }


                    else if (md5check == "f4d9392b1dc66313eadc0169d7d18440")
                    {
                        MessageBox.Show("You have a virus please delete this file!" + f);
                    }
                



                }
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
